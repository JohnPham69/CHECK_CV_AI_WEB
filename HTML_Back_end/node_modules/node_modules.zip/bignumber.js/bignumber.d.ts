/// <reference path="./types.d.ts" />

export = BigNumber;

export as namespace BigNumber;
