require('@babel/register')({
  ignore: ['lib', 'node_modules']
});
