require('./').install();
