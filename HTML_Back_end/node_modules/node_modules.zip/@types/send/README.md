# Installation
> `npm install --save @types/send`

# Summary
This package contains type definitions for send (https://github.com/pillarjs/send).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/send.

### Additional Details
 * Last updated: Tue, 07 Nov 2023 15:11:36 GMT
 * Dependencies: [@types/mime](https://npmjs.com/package/@types/mime), [@types/node](https://npmjs.com/package/@types/node)

# Credits
These definitions were written by [Mike Jerred](https://github.com/MikeJerred), and [Piotr Błażejewicz](https://github.com/peterblazejewicz).
