# Installation
> `npm install --save @types/serve-static`

# Summary
This package contains type definitions for serve-static (https://github.com/expressjs/serve-static).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/serve-static.

### Additional Details
 * Last updated: Wed, 03 Apr 2024 06:07:52 GMT
 * Dependencies: [@types/http-errors](https://npmjs.com/package/@types/http-errors), [@types/node](https://npmjs.com/package/@types/node), [@types/send](https://npmjs.com/package/@types/send)

# Credits
These definitions were written by [Uros Smolnik](https://github.com/urossmolnik), [Linus Unnebäck](https://github.com/LinusU), and [Devansh Jethmalani](https://github.com/devanshj).
