# Installation
> `npm install --save @types/multer`

# Summary
This package contains type definitions for multer (https://github.com/expressjs/multer).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/multer.

### Additional Details
 * Last updated: Fri, 23 Aug 2024 18:08:51 GMT
 * Dependencies: [@types/express](https://npmjs.com/package/@types/express)

# Credits
These definitions were written by [jt000](https://github.com/jt000), [vilicvane](https://github.com/vilic), [David Broder-Rodgers](https://github.com/DavidBR-SW), [Michael Ledin](https://github.com/mxl), [HyunSeob Lee](https://github.com/hyunseob), [Pierre Tchuente](https://github.com/PierreTchuente), and [Piotr Błażejewicz](https://github.com/peterblazejewicz).
